# Finish section 3: Gameplay & user experience

## Context discovered

The repo is mid-changeset: 47 files are modified/untracked on top of `e1a5b21`, and that
working tree **already implements four of the six items**. Test run today: 181/182 pass;
the one failure is a Deal Maker fuzz invariant (`deals game 7 step 393: contract c42-0
binds bankrupt p1`). So this plan is: verify + fix what exists, close the two real gaps,
and leave the tree fully green. Sections 4 (product/legal) and 5 (performance) are
explicitly **out of scope**.

## Item-by-item

### 1. Counter-offers — already built; verify only
- `flipOffer` (`src/game/deals.ts:159`), `counterTo` on `TradeOffer` (`src/game/types.ts:181`),
  engine withdraws the original with no cooldown and emits `TRADE_COUNTERED`
  (`src/game/engine.ts:996-1007`), Counter button on `OfferCard` (`src/ui/Panels.tsx:1171`)
  → seeds `TradePanel` via `counterSeed` (`src/ui/Game.tsx:254`), bots counter lowballs
  (`src/game/ai.ts:436`), i18n in all three locales, tests at `src/game/deals.test.ts:573-644`.
- Work: run the counter tests, click through the flow mentally against the engine rules,
  fix anything found. Expected: nothing.

### 2. Turn alerts in background tabs — already built; verify only
- `src/ui/alerts.ts`: `tableNeed` (my move / offer for me / host seat-request),
  `useTableAlert` flashes `document.title` and fires a `Notification` when
  `document.hidden`, opt-in toggle persisted in `localStorage mply.alerts`, wired into
  `Game.tsx:98-100` and `CashflowGame.tsx:51-53`, strings in `src/i18n/table-*.ts`.
- Work: verify the toggle, permission flow, and that the flash stops on
  `visibilitychange`. Expected: nothing to change.

### 3. Rematch — already built; verify only
- `store.rematch()` (`src/store/store.ts:1386`) reuses the same room/code/connections,
  reseats everyone, new seed, broadcasts `ROOM` so guests follow back to the lobby;
  buttons on `GameOver` (`src/ui/Panels.tsx:1237-1239`) and `CFGameOver`; guests see a
  "waiting" note.
- Work: verify host-only gating and the guest follow path. Expected: nothing.

### 4. In-progress games with open bot seats under Join — close the gaps
Server (`ops/lobbies.py`), host heartbeat (`store.ts:1064-1091`), and list rendering
(`src/ui/PublicRooms.tsx:96-123`) exist. Two gaps:
- **Gating**: the feature is meant for signed-in players, but in-progress rows render for
  everyone; guests click "watch" and get refused with `sign_in_to_join` deep in the join
  flow. Fix in `PublicRooms.tsx`: read `useAccount`; hide `room.inProgress` rows entirely
  when signed out (they're noise for someone who can't use them), keep lobbies visible to
  all. No server change needed.
- **Stale doc**: `docs/accounts.md:133` still says "Started games are not listed publicly".
  Rewrite that bullet to describe the `inProgress`/`openSeats` listing and the watcher →
  take-over path.

### 5. Smarter Deal Maker bots — already built; verify only
- `shareSale` (sell a % of best rent when short, `src/game/ai.ts:469`) and `passPurchase`
  (pay a human to escape a dangerous row, `ai.ts:515`) are wired ahead of `loanRequest`
  in `botTradeOffer` (`ai.ts:578`); tests at `deals.test.ts:651-687`.
- Work: run those tests. Expected: nothing.

### 6. Portrait phone layout — the real build
Bug: at a 400px viewport the page lays out ~457px wide and scrolls sideways.

Root cause: in the ≤780px block (`src/styles/app.css:1784-1790`) `.game__top` is
`flex-wrap: nowrap` with seven unshrinkable children (Leave, turn label, 3D toggle,
Sound, Alerts, LangSwitch, Help) ≈ 570px min-content. The landscape-phone block already
solves the same header with `overflow-x: auto; scrollbar-width: none`
(`app.css:2410-2423`); the portrait block never got it. Contributing: `overflow-x:
hidden` is set only on `body` (`src/styles/global.css:18`), which mobile browsers don't
reliably honor.

Fix (two options at approval — see below):
- **A. Contain the header (minimal)**: in the ≤780px block give `.game__top`
  `overflow-x: auto; scrollbar-width: none;` and add `overflow-x: clip` on `html` in
  `global.css`. Page no longer scrolls sideways; the header scrolls within itself, same
  as landscape phones today.
- **B. Compact icon header (polish)**: same `overflow-x: clip` guard, plus at ≤780px
  render the 3D/Sound/Alerts/Help buttons icon-only (short glyphs, `title`/`aria-label`
  kept) and trim paddings so the whole header fits ~400px with no scrolling at all.
  Touches `Game.tsx:168-203` (or a CSS-only `font-size: 0` + `::first-letter`-style
  trick — prefer a real markup change with visible icons) and `app.css`.

### Also: fix the failing fuzz invariant (part of "fully")
`settleContractsOnBankruptcy` (`src/game/engine.ts:1146-1170`) handles loans and the
**holder** side of passes/shares, but when the bankrupt player is the **grantor** and the
deeds pass to a creditor (or were traded away earlier), the surviving contract still
references the bankrupt id → invariant at `deals.test.ts:553-555` fails. Fix: when a
bankrupt grantor's deeds transfer to the heir, retarget the contract's `grantor` to the
heir (then void if it binds nobody, per the existing :1168-1169 rule); when there is no
heir, void contracts that still name the bankrupt grantor. Add a focused regression test
next to the existing bankruptcy-contract cases in `deals.test.ts`.

## Verification
1. `npx vitest run` — 182/182 green (today: 181/182).
2. `npm run build` — clean.
3. Portrait check: temporarily verify via a quick dev-server render at 400px
   (`document.documentElement.scrollWidth === 400`, no horizontal scrollbar on the page).
4. Manual sanity of the six items against the running dev server where feasible.

No git commit is included — the tree is the user's to commit.
